Team1 = input("What is the name of team 1?")
Team2 = input("What is the name of team 2?")

TeamScored = input("Who scored?")
