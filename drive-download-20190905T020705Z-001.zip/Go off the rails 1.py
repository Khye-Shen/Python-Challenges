TheTime = int(input("What time is it in a 12 hour clock?(don't include wether it is pm or am)"))
PmorAm = input("Is it am or pm?")
if PmorAm in ["am","Am"]:
    print("The time in 24 hour clock is %s" % TheTime)
if PmorAm in ["pm","Pm"]:
    NewTime = TheTime + 1200
    print("The time in 24 hour clock is %s" % NewTime)

