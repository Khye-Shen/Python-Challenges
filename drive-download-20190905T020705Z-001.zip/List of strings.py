MyList = ["Kuala Lumpur","London","Paris","New York","Bangkok"]
print(MyList)

MyList = ["Kuala Lumpur","London","Paris","New York","Bangkok"]
print(MyList[0])

MyList = ["Kuala Lumpur","London","Paris","New York","Bangkok"]
print(MyList[0:3])

MyList = ["Daniel","Jeremy","Nigel","Tomson","Khye Shen"]
print(MyList[0:4])

VideoGameList = ["Tomson, Johnny, John Cena,Daniel"]
GameItems = input("Please add a item to your characters")
VideoGameList.append(GameItems)
print(VideoGameList)
