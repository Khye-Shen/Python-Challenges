
n = int(input("Choose a number"))
if n%3==0:
        print('The number is the multiple of three')
else:
    print('It is not a multiple of three')

