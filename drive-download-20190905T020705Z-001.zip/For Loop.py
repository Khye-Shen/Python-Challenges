for i in range (1,101):
    print(i)

for i in range (0,101,2):
    print(i)

for i in range (1000,0,-10):
    print(i)
