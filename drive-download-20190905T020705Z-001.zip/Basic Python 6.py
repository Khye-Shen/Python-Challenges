TwinTowers = 452
MyCityTallestBuilding = int(input("What's the height of your tallest building in metres?"))
if TwinTowers > MyCityTallestBuilding:
    print("The KL Twin Towers is taller than your building!")
elif TwinTowers == MyCityTallestBuilding:
   print("You must live in KL too!")
else:
    print("Wow! Your city has a very tall building!")








MyHeight = 165
YourHeight = int(input("What's your height in cm?"))
if MyHeight > YourHeight:
    print("I am taller than you!!")
elif TwinTowers == MyCityTallestBuilding:
   print("We are the same height!")
else:
    print("Wow! You are very tall")
