MyList = [1,2,3,4,5,6]
print(sum(MyList))

MyList2 = [print(sum(MyList)),print(max(MyList)),print(len(MyList)),print(min(MyList)),print(sum(MyList)/len(MyList))]
