NumberSide = int(input("Choose a number to build a pyramid"))
for i in range(NumberSide):
        print(' '*(NumberSide-i-1) + '*'*(2*i+1))
