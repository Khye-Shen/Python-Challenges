while True:
    love_subject = input ('What is your favorite subject?')
    if love_subject == "computer science" :
        break


number = 0 #You have to declare this first
while number < 15 or number > 20 :
    print("Please enter a number between 15 and 20")
    number = float(input("enter a number:"))
