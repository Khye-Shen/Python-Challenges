MyName = input('Please enter your name:')
print('Hello',MyName)
