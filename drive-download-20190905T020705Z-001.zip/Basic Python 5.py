
test = input("Is it raining? y/n ")
if test in ["y","yes"]:
    print("Oh dear, no football today!")



test = input("Is it raining? y/n ")
if test in ["y","yes"]:
    print("Oh dear, no football today!")
if test in ["n","No"]:
    print("Great we can play!")
