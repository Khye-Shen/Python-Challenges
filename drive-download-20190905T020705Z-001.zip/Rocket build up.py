Hours = 51

AddedTime = Hours - 48
FinalTime = 2 + AddedTime
print("The time that the alarm would go off would be %s pm" % FinalTime)
