print("Hello World!")
print(4*5)
print(943895/43 )
print(22/7)
