import tkinter # imports main library
import random # For random functions

name_list = ["Jeremy","Daniel","Andrew","Arush"]
window = tkinter.Tk() #so that there's less confusing brackets

def RandomName():
     MyRandom = random.choice(name_list)
     Choosing_Name.configure(text="Picking Name: " + str(MyRandom))

MyTitle = tkinter.Label(window, text="Random Name Generator",font="Helvetica 16 bold")
MyTitle.pack()

MyButton = tkinter.Button(window, text="OK", command=RandomName)
MyButton.pack()

Choosing_Name = tkinter.Label(window, font="Helvetica 16 bold")
Choosing_Name.pack()

window.mainloop()
